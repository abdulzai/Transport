
# --- Add to your existing ingest_to_timestream.py ---
import os, boto3, time
ddb = boto3.resource('dynamodb')
WATERMARK_TABLE = os.environ.get('WATERMARK_TABLE')

def update_watermark(site_id, asset_id, tag, ts_ms):
    if not WATERMARK_TABLE:
        return
    table = ddb.Table(WATERMARK_TABLE)
    pk = f"site#{site_id}#asset#{asset_id}"
    table.update_item(
        Key={"pk": pk, "tag": tag},
        UpdateExpression="SET last_ingested_ts = :t",
        ExpressionAttributeValues={":t": int(ts_ms)}
    )
# call update_watermark(...) after you successfully write each record
