
# OT → AWS Historian Ingest: Watermark & Backfill

This repo adds a DynamoDB watermark table, Step Functions backfill loop, Lambdas, and an SQS queue to orchestrate historical backfills for historian tags. It wires into your existing ingest Lambda that writes to Amazon Timestream.

## Structure
- `terraform/` – DDB table, Lambdas, SQS, Step Functions, EventBridge schedule, IAM
- `lambda_src/` – `compute_backfill.py` and `enqueue_backfill.py`
- `INGEST_WATERMARK_SNIPPET.py` – code to add to your existing `ingest_to_timestream.py`
- `.github/workflows/terraform-validate.yml` – CI for fmt/validate

## Quickstart
```bash
# 1) Build lambda zips
cd lambda_src
zip -9 compute_backfill.zip compute_backfill.py
zip -9 enqueue_backfill.zip enqueue_backfill.py

# 2) Terraform Init/Apply (update variables accordingly)
cd ../terraform
terraform init
terraform apply   -var='project_name=otbridge'   -var='environment=dev'   -var='region=us-east-1'   -var='kinesis_stream_name=YOUR_STREAM'   -var='kinesis_stream_arn=arn:aws:kinesis:us-east-1:123456789012:stream/YOUR_STREAM'   -var='kms_key_arn=arn:aws:kms:us-east-1:123456789012:key/ABC-...'
```

## Edge Backfill Flow
1. Step Functions computes tag gaps using last ingested timestamps in DynamoDB.
2. Each gap is enqueued to SQS.
3. Your edge agent polls SQS, fetches the historical window from the historian, and emits to Kinesis.
4. Ingest Lambda writes to Timestream and updates watermarks.

> Security: read-only historian creds, mTLS/TLS to AWS, KMS encryption, least-priv IAM. Audit via CloudTrail/CloudWatch.
