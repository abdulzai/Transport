
import os, time, boto3
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['WATERMARK_TABLE'])

def _now_ms() -> int:
    return int(time.time() * 1000)

def _minutes(n): return n * 60 * 1000

DEFAULT_LAG_MINUTES = int(os.environ.get("DEFAULT_LAG_MINUTES", "15"))
MAX_WINDOW_MINUTES  = int(os.environ.get("MAX_WINDOW_MINUTES", "120"))
MAX_GAP_MINUTES     = int(os.environ.get("MAX_GAP_MINUTES", "1440"))

def handler(event, context):
    # Scan watermarks; for production, consider pagination and/or partitioned scans
    resp = table.scan(ProjectionExpression="pk, #t, last_ingested_ts", ExpressionAttributeNames={"#t": "tag"})
    items = resp.get("Items", [])
    now = _now_ms()
    lag_cutoff = now - _minutes(DEFAULT_LAG_MINUTES)
    gaps: List[Dict[str, Any]] = []
    for it in items:
        pk = it["pk"]                # "site#X#asset#Y"
        tag = it["tag"]
        last_ts = int(it.get("last_ingested_ts", 0))
        if last_ts == 0:
            # brand new tag: backfill MAX_GAP_MINUTES from lag_cutoff backwards
            start = lag_cutoff - _minutes(MAX_GAP_MINUTES)
            end   = lag_cutoff
        else:
            if last_ts >= lag_cutoff:
                continue  # up-to-date within allowed lag
            start = last_ts + 1
            end   = min(start + _minutes(MAX_WINDOW_MINUTES), lag_cutoff)
        gap = {"pk": pk, "tag": tag, "start_ts": start, "end_ts": end}
        gaps.append(gap)
    # Return list of gaps; Step Functions Map will iterate and call enqueue
    return gaps
