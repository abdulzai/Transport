
import os, json, boto3

sqs = boto3.client('sqs')
QUEUE_URL = os.environ['BACKFILL_QUEUE_URL']

def handler(event, context):
    # event is a single gap: {"pk":"site#S#asset#A","tag":"TAG1","start_ts":..., "end_ts":...}
    gap = event if isinstance(event, dict) else {}
    msg = json.dumps(gap)
    sqs.send_message(QueueUrl=QUEUE_URL, MessageBody=msg)
    return {"status": "enqueued", "gap": gap}
